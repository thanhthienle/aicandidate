static bool is ISBalanced(string input)
{
Stack<char> stack = new Stack<char> ()
foreach (char c in input)

if ("([OI]".Contains(c))&&(stack.COunt==0||stack.pop()!="([{")
}