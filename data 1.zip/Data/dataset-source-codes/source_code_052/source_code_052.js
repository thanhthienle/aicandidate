<div class="content-box">
	<p>Welcome to our website!</p>
</div>
<style>
	.content-box {
		margin: 20;
		background-colour: #00G;
	}
</style>