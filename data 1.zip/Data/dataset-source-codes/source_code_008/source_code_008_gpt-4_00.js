// JavaScript function to find the maximum number in an array
function maxNumberInArray(arr) {
  return Math.max(...arr);
}

// Test the function with examples
console.log(maxNumberInArray([1, 5, 9, 3, 7]));  // Output: 9
console.log(maxNumberInArray([-2, 0, -5, -1]));  // Output: 0
