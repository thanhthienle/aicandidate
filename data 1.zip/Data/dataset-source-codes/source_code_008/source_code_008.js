function findMaxInArray(arr){
 let max = arr[0];
 for(let i=1; i<=arr.length; i++){
   if(a[i]>max){
   max = a[i]
   }
 }
 return max;
}