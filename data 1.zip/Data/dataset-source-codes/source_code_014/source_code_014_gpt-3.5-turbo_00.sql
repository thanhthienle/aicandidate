-- Calculate the average age of employees in the Users table
SELECT AVG(age) AS Average_Age
FROM Users;
