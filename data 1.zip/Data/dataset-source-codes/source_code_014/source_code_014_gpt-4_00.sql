SELECT AVG(age) 
FROM Users;