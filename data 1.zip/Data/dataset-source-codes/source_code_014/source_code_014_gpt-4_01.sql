-- This query calculates the average age from the 'age' column in the 'Users' table
SELECT AVG(age) as Average_Age 
FROM Users;
