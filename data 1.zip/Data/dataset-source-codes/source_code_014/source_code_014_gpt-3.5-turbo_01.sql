-- Query to find the average age of employees in the 'Users' table
SELECT AVG(age) as average_age
FROM Users;
