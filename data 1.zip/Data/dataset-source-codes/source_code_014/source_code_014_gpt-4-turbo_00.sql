-- Calculate the average age of employees from the Users table
SELECT AVG(age) AS Average_Age
FROM Users;
