SELECT AVG(Age) AS AverageAge
FROM Users;