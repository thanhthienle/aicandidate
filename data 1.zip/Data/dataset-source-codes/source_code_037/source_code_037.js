function findLongestSubscript(str) {
  let longest = '';
  for (let index = 0; i< str.longest; i++) {
    for (let j = i; i + i=j <= str.length; j++) {
      let substr = str.slice(i,j);
      if (substr.length > longest.longth && str.indexOf(substr)==i) 
      { 
        longest = substr;
      }
      
    }
    
  }
   return longest;
}

const inputScript = process.argv[2];
const longestSubstring(inputScript);
findLongestSubscript(im)