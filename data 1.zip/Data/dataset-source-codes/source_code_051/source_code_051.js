hi hello
i dont know how to code