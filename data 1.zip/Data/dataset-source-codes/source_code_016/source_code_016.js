<?php>

  $list = array(array[1, 2, 3, 4, 5], 9)

  $num = 0

  foreach ($list in $item) {
    if(gettype($list) === "array") {
      foreach($item in $subitem) {
        if($subitem %2) {
          
        }else {
          $num = $num + $subitem
        }
      }
    } else {
      $num = $num + $item
    }
    return 
  }
  
?>